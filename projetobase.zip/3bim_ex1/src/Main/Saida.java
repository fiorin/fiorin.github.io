package Main;

import java.text.DecimalFormat;

/**
 *
 * @author radames
 */
class Saida {

    public void imprimirDoubleFormatado(String mensagem, String formato, double valor, String unidade) {
        DecimalFormat decimalFormat = new DecimalFormat(formato);
        System.out.println(mensagem + "=>" + decimalFormat.format(valor) + " " + unidade);
    }

    public void imprimirDoubleComDuasCasasDecimais(String mensagem, double valor, String unidade) {
        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        System.out.println(mensagem + "=>" + decimalFormat.format(valor) + " " + unidade);
    }

    public void imprimirRotuloEString(String rotulo, String s) {
        System.out.println(rotulo + " => " + s);
    }

    public void imprimirRotuloEInteiro(String rotulo, int num) {
        System.out.println(rotulo + " => " + num);
    }

    public void imprimirRotuloEInteiro(String rotulo, long num) {
        System.out.println(rotulo + " => " + num);
    }
}
