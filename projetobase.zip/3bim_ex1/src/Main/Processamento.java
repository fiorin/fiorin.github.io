package Main;

/**
 *
 * @author radames
 */
class Processamento {

    public String obterResposta(String parametroDeEntrada) {
        String resposta = parametroDeEntrada.toUpperCase();//transforma em maiúsculas
        return resposta;
    }
}
